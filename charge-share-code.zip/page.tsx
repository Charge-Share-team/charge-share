'use client';
import { useState, useRef } from 'react';
import dynamic from 'next/dynamic';
import Link from 'next/link';

const MapComponent = dynamic(() => import("@/components/ui/MapComponent"), {
  ssr: false,
  loading: () => (
    <div className="absolute inset-0 bg-black flex items-center justify-center">
      <p className="text-zinc-500 font-mono text-xs tracking-widest animate-pulse">INITIALIZING MAP...</p>
    </div>
  ),
});

export default function ExplorePage() {
  const [mapInstance, setMapInstance] = useState<any>(null);
  const [destination, setDestination] = useState<[number, number] | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [isHolding, setIsHolding] = useState(false);
  const holdTimer = useRef<NodeJS.Timeout | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || !mapInstance) return;
    setIsSearching(true);
    try {
      const res  = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`);
      const data = await res.json();
      if (data?.[0]) {
        mapInstance.flyTo([parseFloat(data[0].lat), parseFloat(data[0].lon)], 14);
        setSearchQuery('');
      }
    } catch (err) {
      console.error('Search error:', err);
    } finally {
      setIsSearching(false);
    }
  };

  const startHold = () => {
    setIsHolding(true);
    holdTimer.current = setTimeout(() => { setDestination(null); setIsHolding(false); }, 1000);
  };
  const stopHold = () => {
    if (holdTimer.current) clearTimeout(holdTimer.current);
    setIsHolding(false);
  };

  return (
    /*
      KEY: This element must fill .ps (the scroll container) completely.
      - w-full h-full covers the phone frame on desktop (390×844)
      - min-h-screen covers real mobile viewport
      - overflow-hidden stops scroll so absolute children stay in frame
      - position:relative is the containing block for all absolute children
    */
    <main className="relative w-full h-full min-h-screen overflow-hidden bg-black">

      {/* ── Map: fills entire container ── */}
      <div className="absolute inset-0">
        <MapComponent
          setMapInstance={setMapInstance}
          destination={destination}
          setDestination={setDestination}
        />
      </div>

      {/* ── Search bar: top of screen ── */}
      {!destination && (
        <div className="absolute top-5 left-0 right-0 px-4 z-[500]">
          <form onSubmit={handleSearch} className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search charging stations or cities..."
              className="w-full bg-zinc-900/95 backdrop-blur-xl border border-zinc-800 rounded-2xl py-3.5 px-5 pr-12 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 shadow-2xl"
            />
            <button
              type="submit"
              className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400"
            >
              {isSearching ? '⏳' : '🔍'}
            </button>
          </form>
        </div>
      )}

      {/* ── Cancel navigation: above nav bar ── */}
      {destination && (
        <div className="absolute bottom-24 left-0 right-0 px-8 z-[500]">
          <div className="relative">
            <button
              onMouseDown={startHold}
              onMouseUp={stopHold}
              onTouchStart={startHold}
              onTouchEnd={stopHold}
              className={`w-full py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all duration-200 border ${
                isHolding
                  ? 'bg-red-600 scale-95 border-transparent text-white'
                  : 'bg-zinc-900/95 backdrop-blur-md border-red-500/40 text-red-400'
              }`}
            >
              {isHolding ? 'Release to Confirm' : 'HOLD TO CANCEL'}
            </button>
            {isHolding && (
              <div
                className="absolute bottom-0 left-0 h-1 bg-red-400 rounded-b-2xl"
                style={{ animation: 'cs-progress 1s linear forwards' }}
              />
            )}
          </div>
          <p className="text-[8px] text-zinc-500 text-center mt-2 font-bold uppercase tracking-widest">
            Navigation Active • Hold to Stop
          </p>
        </div>
      )}

      <style jsx global>{`
        @keyframes cs-progress {
          from { width: 0%; }
          to   { width: 100%; }
        }
      `}</style>
    </main>
  );
}